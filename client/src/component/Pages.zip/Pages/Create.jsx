import React, { Component } from 'react'
import './Create.css';
import SimpleReactValidator from 'simple-react-validator';
import { Form, Button, Container, Row, Col, NavDropdown, Navbar, Nav, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css'
import { Link } from 'react-router-dom'
import axios from 'axios'
import SideBar from './SideBar'
import { faLongArrowAltLeft } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Swal from 'sweetalert2'

class Create extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator();

    this.state = {
        kd_barang: "",
        nama_barang: "",
        satuan: "",
        harga_jual: "",
        harga_beli: "",
        stok: "",
        status: 0
        
    }
  }

  handleChange = e => {
    e.preventDefault();
    this.setState({
      [e.target.name]: e.target.value
    })
  }
  handleSubmit = e => {
    e.preventDefault();
    console.log(this.state)
    axios.post("http://localhost:3000/tambah/barang", this.state
    // , {
    //   headers: {
    //     "Content-Type":"application/json",
    //     "Accept" : "application/json"
    //   },
    //   body:JSON.stringify(this.state)
    // }
    ).then((result)=>{
        Swal.fire(
            'Good Job!',
            'Your signup is successfully!',
            'success'
        );
        
      console.log(result.data)
      console.log(this.state)
    })
    .catch(err => {
      console.log(err)
  })
  this.setState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    password2: "",
})
  };

  render() {

    return (
        <div>
             {/* NavBar */}
             <Navbar bg="dark" variant="dark" fixed="top">
                    <Container>
                        <Navbar.Brand href="#home">Navbar</Navbar.Brand>
                        <Form inline>
                            <Nav>
                                <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                                    <NavDropdown.Item href="#">Profile</NavDropdown.Item>
                                    <NavDropdown.Divider />
                                    <NavDropdown.Item onClick={this.handleClick}>
                                        Log out
                    </NavDropdown.Item>
                                </NavDropdown>
                            </Nav>
                        </Form>
                    </Container>
                </Navbar>
                <SideBar />
        <Card
        style={{ width: '50rem' }}
        className="bagan"
      >
          <Card.Body>
          
                                    <i class="fas ">
                                        <FontAwesomeIcon icon={faLongArrowAltLeft} />
                                    </i><Link to='/admin'> Back</Link>
                                <br /><br />
          <Form onSubmit={this.handleSubmit} noValidate>

          <Form.Group as={Row}>
                <Form.Label column sm={2}>
                Kode Barang
                </Form.Label>
                <Col sm={8}>
                <Form.Control
                  
                  value={this.state.kd_barang}
                  type="text"
                  className=""
                  placeholder="Kode Barang *"
                  name="kd_barang"
                  id="kd_barang"
                  noValidate
                  onChange={this.handleChange}
                />
              </Col>
            </Form.Group>

            <Form.Group as={Row}>
                <Form.Label column sm={2}>
                Nama Barang
                </Form.Label>
                <Col sm={8}>
                <Form.Control type="text"
                  
                  value={this.state.nama_barang}
                  className=""
                  placeholder="Nama Barang *"
                  name="nama_barang"
                  id="nama_barang"
                  onChange={this.handleChange}
                  noValidate />
              </Col>
            </Form.Group>

            <Form.Group as={Row}>
                <Form.Label column sm={2}>
                Satuan
                </Form.Label>
                <Col sm={8}>
                <Form.Control type="text"
                  
                  value={this.state.satuan}
                  className=""
                  placeholder="Satuan *"   
                  name="satuan"
                  onChange={this.handleChange}
                  noValidate />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
                <Form.Label column sm={2}>
                Harga Jual
                </Form.Label>
                <Col sm={8}>
                <Form.Control type="text"
                  
                  value={this.state.harga_jual}
                  className=""
                  placeholder="Harga Jual *"   
                  name="harga_jual"
                  onChange={this.handleChange}
                  noValidate />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
                <Form.Label column sm={2}>
                Harga Beli
                </Form.Label>
                <Col sm={8}>
                <Form.Control type="text"
                  
                  value={this.state.harga_beli}
                  className=""
                  placeholder="Harga Beli *"   
                  name="harga_beli"
                  onChange={this.handleChange}
                  noValidate />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
                <Form.Label column sm={2}>
                Stok
                </Form.Label>
                <Col sm={8}>
                <Form.Control type="text"
                  
                  value={this.state.stok}
                  className=""
                  placeholder="Stok *"   
                  name="stok"
                  onChange={this.handleChange}
                  noValidate />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
                <Form.Label column sm={2}>
                Status
                </Form.Label>
            <Col sm={8}>
                <Form.Check type="radio"
                  value={this.state.status}
                  label="0"
                  className=""
                  placeholder="status"   
                  name="status"
                  onChange={this.handleChange}
                  noValidate />
              </Col>
            </Form.Group>
            <Form.Group as={Row}>
            <Col sm={{ span: 10, offset: 2 }}>
            <Button type="submit" >Create</Button>
            </Col>
            </Form.Group>
          </Form>
          </Card.Body>
          </Card>
          </div>
    );
  }
}

export default Create;
