import React, { Component } from "react";
import { Button, Navbar, Nav, Container, Col, Row, Form, NavDropdown } from "react-bootstrap";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import { Redirect, Link } from "react-router-dom";
import ToolkitProvider, { SearchBar, Search, defaultSorted } from "react-bootstrap-table2-toolkit";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import './Admin.css'
import Swal from 'sweetalert2'
import Create from './Create'
import SideBar from "./SideBar";

class Admin extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token");

    let loggedIn = true;
    if (token == null) {
      loggedIn = false;
    }

    this.state = {
      error: null,
      loggedIn,
      data: [],
      isLoaded: false,
    };
  }

  componentDidMount() {
    fetch("http://localhost:3000/barang?page=&limit=&search=&sort=")
      .then((res) => res.json())
      .then(
        (json) => {
          this.setState({
            isLoaded: true,
            data: json.data,
          });
        },
        (error) => {
          this.setState({
            isLoaded: true,
            error: Swal.fire(
              'The Internet?',
              'That thing is still around?',
              'question'
            ),
          });
        }
      );
  }

  handleClick = (e) => {
    localStorage.removeItem("token");
    this.props.history.push("/login");
  };
  render() {
    if (this.state.loggedIn === false) {
      return <Redirect to="/login" />;
    }

    const customTotal = (from, to, size) => (
      <span className="react-bootstrap-table-pagination-total">
        Showing {from} to {to} of {size} Results
      </span>
    );

    const options = {
      paginationSize: 4,
      pageStartIndex: 0,
      alwaysShowAllBtns: true, // Always show next and previous button
      // withFirstAndLast: false, // Hide the going to First and Last page button
      // hideSizePerPage: true, // Hide the sizePerPage dropdown always
      // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
      firstPageText: "First",
      prePageText: "Back",
      nextPageText: "Next",
      lastPageText: "Last",
      nextPageTitle: "First page",
      prePageTitle: "Pre page",
      firstPageTitle: "Next page",
      lastPageTitle: "Last page",
      showTotal: true,
      paginationTotalRenderer: customTotal,
      disablePageTitle: true,
      sizePerPageList: [
        {
          value: 5,
        },
      ], // A numeric array is also available. the purpose of above example is custom the text
    };
    const { SearchBar } = Search;
    const columns = [
      {
        dataField: "kd_barang",
        text: "Kode Barang",
        sort: true,
      },
      {
        dataField: "nama_barang",
        text: "Nama Barang",
        sort: true,
      },
      {
        dataField: "satuan",
        text: "Satuan",
      },
      {
        dataField: "harga_jual",
        text: "Harga Jual",
      },
      {
        dataField: "harga_beli",
        text: "Harga Beli",
      },
      {
        dataField: "stok",
        text: "Stock",
      },
      {
        dataField: "Link",
        text: "Action",
        formatter: (rowContent, row, props) => {
          return (
            <div>
              <Container>
                <Row>
                  <Col xa="auto">
                    <Link to={"edit/" + row.id}>
                      <Button variant="danger" className="md-2" block>
                        Edit
                                    </Button>
                    </Link>
                  </Col>
                  <Col xa="auto">
                    {/* <Link to="/remove"> */}
                    <Button variant="danger" className="xs-2" onClick={props.remove} block>
                      Delete
                                    </Button>
                    {/* </Link> */}
                  </Col>
                </Row>
              </Container>
            </div >
          )
        }
      }
    ];

    const defaultSorted = [
      {
        dataField: "name",
        order: "desc",
      },
    ];



    var { error, isLoaded, data } = this.state;
    if (error) {
      return <div>{error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <div>
          {/* NavBar */}
          <Navbar bg="dark" variant="dark" fixed="top">
            <Container>
              <Navbar.Brand href="#home">Navbar</Navbar.Brand>
              <Form inline>
                <Nav>
                  <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                    <NavDropdown.Item href="#">Profile</NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item onClick={this.handleClick}>
                      Log out
                    </NavDropdown.Item>
                  </NavDropdown>
                </Nav>
              </Form>
            </Container>
          </Navbar>
          <SideBar />
          <Container>

            <ToolkitProvider
              keyField="id"
              data={data}
              columns={columns}
              search>
              {(props) => (
                <div className="back">
                  <div>

                    <Row>

                      <Col md={-2}>
                        <Link to="/create"><Button className="mr-2" variant="success" block="">Create</Button></Link>
                      </Col>
                      <Col xs={-1}>
                        <Button className="mr-2" variant="warning" block="">Update</Button>
                      </Col>
                      <Col xs={-1}>
                        <Button variant="danger" block="">Delete</Button>
                      </Col>

                      <Col>
                        <div className="float-right">
                          <SearchBar {...props.searchProps} />
                        </div>
                      </Col>
                    </Row>
                  </div>

                  <br />

                  <BootstrapTable {...props.baseProps}
                    boostrtap4
                    keyField="id"
                    data={data}
                    columns={columns}
                    defaultSorted={defaultSorted}
                    pagination={paginationFactory(options)}
                    headerWrapperClasses="foo" />
                </div>
              )}
            </ToolkitProvider>
          </Container>
        </div>
      );
    }
  }
}

export default Admin;
