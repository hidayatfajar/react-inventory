import React, { Component } from 'react'
import { BrowserRouter, Route, Switch } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import './Config.css'
import Login from './Login';
import Signup from './Signup';
import Table from './Table';
import Welcome from './Welcome';
import Logout from '../Sidebar/Logout';
import Admin from './Admin';
import Admin1 from './Admin1';
import Create from './Create';
import SideBar from './SideBar';
import Homepage from './Homepage';


export default class Config extends Component {
    render() {
        return (
            <div>
            <BrowserRouter>
                <Switch>
                    <Route exact path="/" component={Welcome} />
                    <Route exact path="/home" component={Homepage} />
                    <Route path="/admin" component={Admin} />
                    <Route path="/admin1" component={Admin1} />
                    <Route path="/login" component={Login} />
                    <Route path="/signup" component={Signup} />
                    <Route path="/table" component={Table} />
                    <Route path="/logout" component={Logout} />
                    <Route exact path="/create" component={Create} />

                </Switch>
            </BrowserRouter>
                    </div >
                )
    }
}

