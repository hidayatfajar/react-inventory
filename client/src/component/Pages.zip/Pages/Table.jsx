import React, { Component } from "react";
import { Button, Navbar, Nav, Container } from "react-bootstrap";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import { Redirect, Link } from "react-router-dom";
import ToolkitProvider, { SearchBar, Search, defaultSorted } from "react-bootstrap-table2-toolkit";
import Swal from 'sweetalert2'

class Table extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token");

    let loggedIn = true;
    if (token == null) {
      loggedIn = false;
    }

    this.state = {
      error: null,
      loggedIn,
      data: [],
      isLoaded: false,
    };
  }

  componentDidMount() {
    fetch("http://localhost:3000/barang")
      .then((res) => res.json())
      .then(
        (json) => {
          this.setState({
            isLoaded: true,
            data: json.data,
          });
        },
        (error) => {
          this.setState({
            isLoaded: true,
            error: Swal.fire(
              'The Internet?',
              'That thing is still around?',
              'question'
          ) ,
          });
        }
      );
  }

  handleClick = (e) => {
    localStorage.removeItem("token");
    this.props.history.push("/login");
  };
  render() {
    if (this.state.loggedIn === false) {
      return <Redirect to="/login" />;
    }

    const customTotal = (from, to, size) => (
      <span className="react-bootstrap-table-pagination-total">
        Showing {from} to {to} of {size} Results
      </span>
    );

    const options = {
      paginationSize: 4,
      pageStartIndex: 0,
      alwaysShowAllBtns: true, // Always show next and previous button
      // withFirstAndLast: false, // Hide the going to First and Last page button
      // hideSizePerPage: true, // Hide the sizePerPage dropdown always
      // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
      firstPageText: "First",
      prePageText: "Back",
      nextPageText: "Next",
      lastPageText: "Last",
      nextPageTitle: "First page",
      prePageTitle: "Pre page",
      firstPageTitle: "Next page",
      lastPageTitle: "Last page",
      showTotal: true,
      paginationTotalRenderer: customTotal,
      disablePageTitle: true,
      sizePerPageList: [
        {
          text: "5",
          value: 5,
        },
        {
          text: "10",
          value: 10,
        },
        {
          text: "All",
          value: 100,
        },
      ], // A numeric array is also available. the purpose of above example is custom the text
    };
    const { SearchBar } = Search;
    const columns = [
      {
        dataField: "kd_barang",
        text: "ID",
        sort: true,
      },
      {
        dataField: "nama_barang",
        text: "Nama Barang",
        sort: true,
      },
      {
        dataField: "harga_jual",
        text: "Harga Jual",
      },
      {
        dataField: "harga_beli",
        text: "Harga Beli",
      },
      {
        dataField: "stok",
        text: "Stok",
      },
      {
        dataField: "status",
        text: "Status",
      },
    ];

    const defaultSorted = [
      {
        dataField: "name",
        order: "desc",
      },
    ];

    

    var { error, isLoaded, data } = this.state;
    if (error) {
      return <div>{error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <div>
          <Container>
          <ToolkitProvider 
          keyField="id" 
          data={data} 
          columns={columns} 
          search>
          {(props) => (
          <div>
          <SearchBar {...props.searchProps} />
          <BootstrapTable {...props.baseProps}
          boostrtap4 
          keyField="id" 
          data={data} 
          columns={columns} 
          defaultSorted={defaultSorted} 
          pagination={paginationFactory(options)} 
          headerWrapperClasses="foo" />
        </div>
      )}
    </ToolkitProvider>
          </Container>   
        </div>
      );
    }
  }
}

export default Table;
